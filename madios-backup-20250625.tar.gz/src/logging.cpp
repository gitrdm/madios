#include "logging.h"

namespace madios {
LogLevel CURRENT_LOG_LEVEL = LOG_WARN;
} // namespace madios
